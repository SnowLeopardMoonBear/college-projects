import time #단어입력시간을 저장하기 위한 모듈
import random as rd #랜덤단어퀴즈를 위한 모듈
import webbrowser #뭘까요? ㅎㅎㅎ 코드를 잘 보면 어디에서 쓰였는지 알 수 있습니다.
import pickle #외부에서 단어장을 불러오기 위한 모듈

with open('external_word_list.txt', 'rb') as f: #'wordbook.py'와 같은 폴더에 저장된 단어장인 'external_word_list.txt'를 불러옵니다.
    word_list = pickle.load(f)

def go_back(): #여러 곳에서 쓰이는 부프로그램입니다. 각 부프로그램에서 메인함수로 돌아갈 때마다 반복적으로 쓰입니다.
    temp = input("메인 메뉴로 돌아가시려면 y를, 계속하시려면 n를 입력해주세요: ") #키보드 인풋을 받아옵니다.
    try:
        if temp == 'y': #'y'키를 누르면 메인함수를 호출해 메인메뉴로 돌아갑니다
            main()
        elif temp == 'n': # 'n'키를 누르면 'n'을 리턴하고, 각 부프로그램에서는 리턴된 값을 신호로 받아들여 분기를 선택합니다.
            return 'n'
        elif temp != 'y' and temp != 'n': # 'y', 'n'이 아닌 다른 키를 입력하면 예외처리됩니다.
            raise Exception('wrong input')
    except Exception: # 엉뚱한 값을 입력했을 때 예외처리로 넘어가게 됩니다.
        print('잘못 입력하셨습니다.')
        go_back()


def words():  # 단어를 추가/삭제하는 부프로그램입니다.
    global word_list

    def insert(): #단어를 추가하는 부프로그램내 부프로그램입니다.
        temp = [] #영단어 한 개와, 이에 대한 뜻, 예문을 임시로 저장하는 리스트입니다.
        temp.append(input('영단어를 입력해주세요: ')) #단어와 뜻, 예문, 저장시각을 입력받아 임시 리스트에 저장합니다.
        temp.append(input('뜻을 입력해주세요: '))
        temp.append(input('예문을 입력해주세요: '))
        temp.append(time.ctime())
        word_list.append(temp) #단어의 이름, 뜻, 예문, 저장시각을 단어장에 추가합니다.
        print('추가되었습니다')
        if go_back() == 'n': #go_back() 부프로그램을 호출해 메인메뉴로 돌아갈지 결정합니다. 안 돌아간다면 단어추가를 계속합니다.
            insert()

    def remove(): #단어를 삭제하는 부프로그램 내의 부프로그램입니다.
        temp = input('삭제할 단어를 입력해주세요: ') #삭제할 단어를 입력받습니다.
        address = None
        for i in range(len(word_list)): #단어장에 삭제할 단어가 있는지 탐색합니다.
            if word_list[i][0] == temp:
                address = i
        if address != None: #삭제할 단어가 있으면 삭제합니다.
            del word_list[address]
            print('삭제되었습니다!')
        else: #삭제할 단어가 없으면 없는 단어라고 알려줍니다.
            print('없는 단어입니다')

        if go_back() == 'n': #go_back() 부프로그램을 호출해 메인메뉴로 돌아갈지 결정합니다. 안 돌아간다면 단어삭제를 계속합니다.
            remove()

    insert_or_remove = input('단어를 추가하시려면 1, 삭제하시려면 2를 입력해주세요: ') #단어 추가/삭제를 선택합니다.
    if insert_or_remove == '1':
        insert()
    elif insert_or_remove == '2':
        remove()
    else:
        print('잘못 입력하셨습니다')
        words()


def memorize(): #암기하기 좋도록 단어를 랜덤하게 하나씩 보여주는 부프로그램입니다.
    try: # 만약 저장된 단어가 없으면 예외처리되어 메인메뉴로 돌아갑니다.
        if len(word_list) == 0:
            raise Exception
    except Exception:
        print('저장된 단어가 없습니다.')
        main()

    print('랜덤암기입니다. 다음 단어로 넘어가시려면 1을, 메인 메뉴로 나가시려면 다른 키를 입력해주세요')

    def random_words(): #단어를 무작위로 하나씩 보여주기 위해 정의된 부프로그램입니다
        print(word_list[rd.randint(0, len(word_list) - 1)][0:2])
        temp = input() #입력값이 '1'이면 다음 단어를 보여줍니다.
        try:
            if temp == '1':
                random_words()
            else: #입력값이 1이 아닌 모든 경우엔 예외처리되어 메인메뉴로 나가집니다.
                raise Exception
        except Exception:
            main()

    random_words() #랜덤한 단어를 실제로 하나씩 보여주라는 명령입니다.


def show_words(): #단어장에 있는 모든 단어를 보여주는 부분입니다.
    try:
        if len(word_list) == 0:
            raise Exception
        for i in range(len(word_list)): #한 줄에 한 단어씩 이름, 뜻, 예문, 저장시간을 출력합니다.
            print(word_list[i])
        input_value = input()
        if input_value == '' or input_value != '':
            main()
    except (Exception): #단어장이 비어있으면 예외처리하고 메인으로 튕깁니다
        print('저장된 단어가 없습니다')
        main()


def search(): #단어장의 특정 단어를 검색하면 뜻과 예문을 보여줍니다
    try:
        if len(word_list) == 0: #단어장이 비었으면 예외처리!
            raise Exception

        word_search = input('찾으실 영단어를 입력해주세요: ')
        word_retrieve = ''
        for i in range(len(word_list)): #단어장을 전부 훑으면서 입력값과 일치하는 단어를 찾고, 뜻과 예문을 출력합니다.
            if word_list[i][0] == word_search:
                word_retrieve = '뜻: ' + word_list[i][1] + ', 예문: ' + word_list[i][2]
        if word_retrieve != '':
            print(word_retrieve)
        else:
            print('없는 단어입니다')

        if go_back() == 'n': #계속할지를 묻습니다.
            search()

    except Exception: #예외처리를 실행하고 메인으롤 돌아갑니다.
        print('저장된 단어가 없습니다')
        main()


def test(): #단어의 뜻을 맞히는 퀴즈입니다. 랜덤한 단어가 하나 주어지고, 4개의 선택지 중에 하나를 고르면 됩니다.
    if len(word_list) < 4: #선택지 4개를 만들려면 당연히 단어가 4개 이상이어야겠죠?
        print('단어퀴즈를 보시려면 최소 4개의 단어를 저장해주세요')
        main()

    test_list = [] #퀴즈를 위해 지역변수로 임시 리스트를 하나 만들었습니다.

    while len(test_list) < 4: #임시 리스트에 중복 없이 랜덤한 단어를 4개 채워넣습니다.
        random_word = word_list[rd.randint(0, len(word_list) - 1)]
        count = 0
        for i in range(len(test_list)):
            if test_list[i] == random_word:
                count += 1
        if count == 0:
            test_list.append(random_word)

    print('다음 단어의 뜻으로 알맞은 것은?')
    index = rd.randint(0, 3) #정답 단어를 4개짜리 리스트에서 하나 뽑습니다.
    print(test_list[index][0])
    for i in range(4): #리스트에 있는 단어의 뜻들을 차례대로 선택지로 출력합니다.
        print(str(i + 1) + '.  ' + test_list[i][1])

    try:
        input_number = int(input())
        if input_number > 4 or input_number < 1:
            raise Exception # 입력값이 숫자지만 1~4까지의 숫자가 아닌 경우 예외처리합니다
    except (ValueError, Exception): #숫자가 아닌 문자열이나, 범위를 초과하는 숫자를 입력하면 예외처리합니다.
        print('1부터 4까지의 숫자만 입력해주세요')
        test()

    if (input_number - 1) == index: #입력값 - 1이 정답 단어의 인덱스와 일치하면 정답판정
        print('맞았습니다!')
    else:
        print('틀렸습니다...') #그렇지 않다면 오답판정합니다.

    if go_back() == 'n': #계속할지 물어봅니다
        test()


def save():
    if input('저장하시려면 y를, 취소하시려면 기타 키를 눌러주세요: ') == 'y':
        with open('external_word_list.txt', 'wb') as f: #만든 단어장 list를 외부 메모장에 자료형 그대로 저장해줍니다.
           pickle.dump(word_list, f)

        print('저장되었습니다.')
        main()
    else:
        main()


def main(): #메인메뉴입니다. ARS전화처럼 작동한다고 생각하시면 됩니다.
    print('#########################################################################')
    print('          안녕하세요, SnowLeopard의 스마트 단어장입니다.                  ')
    print('    단어추가/제거는 1, 단어외우기는 2, 저장단어 보기는 3, 단어검색은 4      ')
    print('       단어퀴즈는 5, 단어장 저장은 6을 입력하고 엔터를 눌러주세요           ')
    print('#########################################################################')
    selection = input() #변수를 만들어 메뉴 선택하는 입력값을 받아옵니다
    if selection == '1': #단어를 추가/제거합니다.
        words()
    elif selection == '2': #랜덤단어를 하나씩 띄워서 암기를 돕습니다.
        memorize()
    elif selection == '3': #저장된 단어를 한 줄씩 출력합니다.
        show_words()
    elif selection == '4': #입력한 단어의 뜻과 예문을 검색합니다
        search()
    elif selection == '5': #랜덤하게 띄워주는 단어퀴즈를 풀 수 있습니다.
        test()
    elif selection == '6': #단어장을 외부 파일에 저장합니다.
        save()
    elif selection == '7': #곰티곰티는 귀엽습니다 >ㅂ<
        print(
            'Easter egg: 곰사랑 캠페인 ^오^ \n곰은 귀엽습니다. 하지만 동시에 놀랄만큼 영리하고 강인한 모습이 매력적인 동물이죠. \n안타깝게도 기후변화, 밀렵, 서식지의 파괴로 인해 많은 곰들이 멸종 위기에 처해있습니다. \n우리 모두 곰을 아끼고 사랑합시다. \n-반달가슴곰, 불곰, 아메리카흑곰, 느림보곰, 안경곰, 말레이곰, 태양곰, 판다, (지금은 세상에 없는)아르크토테리움 일동-')
        webbrowser.open("https://studyforus.com/humor/15905#&gid=1&pid=1")
        main()
    elif selection == '0':
        print('상담원 연결은 없습니다. 여기는 ARS 콜센터가 아닙니다.')
        main()
    else:
        print('잘못 입력하셨습니다.')
        main()


if __name__ == '__main__':  # 이 코드를 통해 Python 프로그램이 실행될 때 main함수를 자동으로 실행해줍니다.
    main()